from django.contrib import admin
from .models import Visit

admin.site.register(Visit)
