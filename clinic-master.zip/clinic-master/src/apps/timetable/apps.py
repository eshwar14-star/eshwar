from django.apps import AppConfig


class Config(AppConfig):
    name = 'timetable'
    verbose_name = 'Расписание работы поликлиники'