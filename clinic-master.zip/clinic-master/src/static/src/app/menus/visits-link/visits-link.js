angular.module('visits-link', [
  'visitsLinkDirective'
]);
