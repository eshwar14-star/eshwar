Clinic frontend
===============

Установка
---------
Для работы с исходным кодом Angular-приложения
необходима установка nodejs.
После установки nodejs на вашей системе, выполнить:

```
$ npm -g install grunt-cli bower
$ npm install
$ bower install
$ grunt watch
```

Лицензия
--------

Copyright &copy; 2015 Максим Чернятевич.
*clinic* распространяется на условиях лицензии MIT:

[https://raw.githubusercontent.com/vechnoe/clinic/master/LICENSE](https://raw.githubusercontent.com/vechnoe/clinic/master/LICENSE) 


Контакты
--------       
Сообщения об ошибках и пожелания отправляйте на почту:
[maxim.chernyatevich@gmail.com](mailto:maxim.chernyatevich@gmail.com)
